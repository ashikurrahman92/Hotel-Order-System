
package com.mycompany.hotelordersystem;
public class Burger extends FoodItem {
    public Burger(String itemName, double price) {
        super(itemName, price);
    }

    @Override
    public double calculatePrice(int quantity) {
        return super.calculatePrice(quantity); // no discount
    }
}
