package com.mycompany.hotelordersystem;

public class FoodItem {
     protected String itemName;
    protected double price;

    public FoodItem(String itemName, double price) {
        this.itemName = itemName;
        this.price = price;
    }

    public double calculatePrice(int quantity) {
        return quantity * price; // default calculation
    }

    public void displayItem() {
        System.out.println(itemName + " - Price: " + price);
    }
    
}
