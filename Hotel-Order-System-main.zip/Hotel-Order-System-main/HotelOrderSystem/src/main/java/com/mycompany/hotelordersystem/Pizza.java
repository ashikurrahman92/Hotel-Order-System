
package com.mycompany.hotelordersystem;
public class Pizza extends FoodItem {
    public Pizza(String itemName, double price) {
        super(itemName, price);
    }

    @Override
    public double calculatePrice(int quantity) {
        return super.calculatePrice(quantity) + 50; // extra cheese charge
    }
}