
package com.mycompany.hotelordersystem;
public abstract class Order {
    protected Customer customer;
    protected FoodItem foodItem;
    protected int quantity;

    public Order(Customer customer, FoodItem foodItem, int quantity) {
        this.customer = customer;
        this.foodItem = foodItem;
        this.quantity = quantity;
    }

    public abstract void confirmOrder(); // Abstract method
}