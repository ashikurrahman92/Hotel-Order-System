
package com.mycompany.hotelordersystem;
public class Main {
    public static void main(String[] args) {
        Customer c1 = new Customer("Rahim", "017XXXXXXXX");

        FoodItem pizza = new Pizza("Cheese Pizza", 500);
        FoodItem cake = new Cake("Chocolate Cake", 800);
        FoodItem burger = new Burger("Beef Burger", 250);

        Order o1 = new FoodOrder(c1, pizza, 2);
        Order o2 = new FoodOrder(c1, cake, 1);
        Order o3 = new FoodOrder(c1, burger, 3);

        o1.confirmOrder();
        System.out.println("----------------");
        o2.confirmOrder();
        System.out.println("----------------");
        o3.confirmOrder();
    }
}