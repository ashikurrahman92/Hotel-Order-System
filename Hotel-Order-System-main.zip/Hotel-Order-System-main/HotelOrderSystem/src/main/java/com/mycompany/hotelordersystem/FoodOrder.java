/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelordersystem;
public class FoodOrder extends Order {
    public FoodOrder(Customer customer, FoodItem foodItem, int quantity) {
        super(customer, foodItem, quantity);
    }

    @Override
    public void confirmOrder() {
        System.out.println("Order Confirmed for " + customer.getName());
        System.out.println("Item: " + foodItem.itemName + " | Quantity: " + quantity);
        System.out.println("Total Price: " + foodItem.calculatePrice(quantity));
    }
}